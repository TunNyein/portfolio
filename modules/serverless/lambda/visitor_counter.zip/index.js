import {
  DynamoDBClient
} from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  UpdateCommand
} from "@aws-sdk/lib-dynamodb";
import {
  CloudWatchClient,
  PutMetricDataCommand
} from "@aws-sdk/client-cloudwatch";

const db = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const cw = new CloudWatchClient({});

const TABLE = "visitor-counter";

export const handler = async (event) => {
  try {
    console.log(" Incoming request:", JSON.stringify(event));

    // Update counter atomically
    const result = await db.send(new UpdateCommand({
      TableName: TABLE,
      Key: { id: "counter" },
      UpdateExpression: "SET #c = if_not_exists(#c, :start) + :inc",
      ExpressionAttributeNames: { "#c": "count" },
      ExpressionAttributeValues: { ":inc": 1, ":start": 0 },
      ReturnValues: "UPDATED_NEW"
    }));

    const visits = result.Attributes.count;

    // Send custom metric to CloudWatch
    await cw.send(
      new PutMetricDataCommand({
        Namespace: "TunNyein/VisitorCounter",
        MetricData: [
          {
            MetricName: "PageViews",
            Value: 1,
            Unit: "Count"
          }
        ]
      })
    );

    console.log("📊 Updated visitor count:", visits);
    console.log("📈 CloudWatch metric sent");

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ visits })
    };
  } catch (err) {
    console.error("❌ Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};

