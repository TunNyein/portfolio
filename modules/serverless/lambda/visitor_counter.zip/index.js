const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const table = process.env.TABLE_NAME;
  const key = { id: 'counter' };

  try {
    const get = await dynamo.get({ TableName: table, Key: key }).promise();
    let count = 0;
    if (get.Item && get.Item.count) count = get.Item.count;

    count += 1;

    await dynamo.put({ TableName: table, Item: { id: 'counter', count } }).promise();

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ count })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Internal error' })
    };
  }
};
