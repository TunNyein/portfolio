const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { CloudWatchClient, PutMetricDataCommand } = require("@aws-sdk/client-cloudwatch");

const db = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const cw = new CloudWatchClient({});

const TABLE = "visitor-counter";

exports.handler = async (event) => {
  try {
    console.log("Incoming request:", JSON.stringify(event));

    const result = await db.send(new UpdateCommand({
      TableName: TABLE,
      Key: { id: "counter" },
      UpdateExpression: "SET #c = if_not_exists(#c, :start) + :inc",
      ExpressionAttributeNames: { "#c": "count" },
      ExpressionAttributeValues: { ":inc": 1, ":start": 0 },
      ReturnValues: "UPDATED_NEW"
    }));

    const visits = result.Attributes.count;

    await cw.send(
      new PutMetricDataCommand({
        Namespace: "TunNyein/VisitorCounter",
        MetricData: [
          { MetricName: "PageViews", Value: 1, Unit: "Count" }
        ]
      })
    );

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ visits })
    };
  } catch (err) {
    console.error("Error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
};

